
import React from 'react';

function App() {
    return (
        <div>
            <h1>Welcome to Tekken 8 Training App</h1>
            <p>Explore moves, compare characters, and improve your skills!</p>
        </div>
    );
}

export default App;
